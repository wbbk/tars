# Contributing

If you contributed but cannot find your ID here, please submit PR and add your GitHub ID to both [Tars repo](https://github.com/TarsCloud/Tars/pulls) and [here](https://github.com/TarsCloud/TarsFramework/pulls).

## TarsFramework

- diracccc
- ETZhangSX
- jerrylucky
- lanhy
- MindHook
- mygrsun
- renyang9876
- ruanshudong
- shevqko
- wincsb
- ypingcn
- yuansx
