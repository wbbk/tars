#!/bin/bash

TARS_PATH/tarsAdminRegistry/util/execute.sh tarsAdminRegistry stop


