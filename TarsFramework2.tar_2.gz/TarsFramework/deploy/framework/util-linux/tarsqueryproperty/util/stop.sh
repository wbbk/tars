#!/bin/bash

sh TARS_PATH/tarsqueryproperty/util/execute.sh tarsqueryproperty stop

