#!/bin/bash

sh TARS_PATH/tarsnode/util/execute.sh tarsnode stop


