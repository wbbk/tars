#!/bin/bash

sh TARS_PATH/tarslog/util/execute.sh tarslog start

