#!/bin/bash

sh TARS_PATH/tarsquerystat/util/execute.sh tarsquerystat start

