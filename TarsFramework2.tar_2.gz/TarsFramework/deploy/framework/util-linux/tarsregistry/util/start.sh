#!/bin/bash

sh TARS_PATH/tarsregistry/util/execute.sh tarsregistry start
