#!/bin/bash

TARS_PATH/tarsnode/util/monitor.sh


