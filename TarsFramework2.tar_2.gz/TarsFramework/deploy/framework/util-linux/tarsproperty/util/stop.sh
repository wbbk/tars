#!/bin/bash

sh TARS_PATH/tarsproperty/util/execute.sh tarsproperty stop

