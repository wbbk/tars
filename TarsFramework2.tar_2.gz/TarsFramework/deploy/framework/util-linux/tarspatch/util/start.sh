#!/bin/bash

sh TARS_PATH/tarspatch/util/execute.sh tarspatch start
