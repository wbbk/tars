该工程是Tars 协程编程示例的代码


目录名称 |功能
-----------------|----------------
client/BServer/AServer   |   协程编程的示例程序，client访问BServer，BServer用协程方式去并行和串行访问AServer
testCoro/testParallelCoro   |  协程编程的示例程序，自定义或者继承框架的协程类
