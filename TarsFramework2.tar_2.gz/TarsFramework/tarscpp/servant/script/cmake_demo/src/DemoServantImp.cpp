﻿#include "DemoServantImp.h"
#include "servant/Application.h"

using namespace std;

//////////////////////////////////////////////////////
void DemoServantImp::initialize()
{
    //initialize servant here:
    //...
}

//////////////////////////////////////////////////////
void DemoServantImp::destroy()
{
    //destroy servant here:
    //...
}

